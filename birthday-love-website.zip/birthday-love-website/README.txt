BIRTHDAY LOVE WEBSITE — ANDROID SETUP

1) FOLDER STRUCTURE
website/
  index.html
  README.txt
  media/
    photos/
      photo1.jpg
      photo2.jpg
      photo3.jpg
      photo4.jpg
      photo5.jpg
      photo6.jpg
    videos/
      video1.mp4
      video2.mp4
    song/
      our-song.mp3

2) ADDING YOUR 6 PHOTOS
- Put your six photos into media/photos/
- The easiest method is to keep the names photo1.jpg ... photo6.jpg.
- If your files have different names, open index.html and edit PHOTOS near the bottom.
- Example: const PHOTOS = ["IMG_1234.jpg", "IMG_5678.jpg", ...];

3) ADDING YOUR 2 VIDEOS
- Put both videos into media/videos/
- MP4 is recommended for broad phone/browser compatibility.
- Keep the example names video1.mp4 and video2.mp4, or edit VIDEOS in index.html.

4) ADDING YOUR SONG
- Put the MP3 into media/song/
- Keep the name our-song.mp3, or edit SONG in index.html.
- Browsers block unsolicited autoplay. The first permanent song playback must be started by the user. The upload button also requires a tap.

5) TEST ON ANDROID
Option A — easiest:
- Open the project folder in a code editor/file manager that can preview HTML.
- If the preview cannot load local media, use a local HTTP server.

Option B — Termux:
- Install Termux from a trusted source.
- Open Termux and go to the project directory.
- Run: python -m http.server 8080
- Open Chrome and visit: http://127.0.0.1:8080
- Stop the server with Ctrl+C.

6) DEPLOY FOR FREE
GitHub Pages:
- Create a GitHub account/repository.
- Upload index.html, README.txt and the entire media folder.
- Repository Settings → Pages.
- Select deployment from the main branch/root.
- GitHub gives you a public Pages address to send to her.
- Make sure media/photos, media/videos and media/song are uploaded with the same capitalization as the filenames in index.html.

Alternative: Netlify or Cloudflare Pages can deploy the same static folder. Upload/connect the repository and use the folder containing index.html as the site root.

7) IMPORTANT
- Do not rename media folders unless you also edit the paths in index.html.
- Avoid spaces/special characters in filenames; simple names such as photo1.jpg are safest.
- Compress very large photos/videos before deployment for faster phone loading.
- This project contains no analytics, tracking, ads, database, or external upload service.
- Google Fonts are referenced externally. If you need a fully offline version, replace the font links with locally hosted font files.

8) FINAL CHECK
Open the deployed site on the actual Android phone:
- Tap the opening button.
- Check all six photos.
- Tap a photo and test previous/next/close.
- Play both videos.
- Start the song.
- Scroll to the final question and tap either positive button.
